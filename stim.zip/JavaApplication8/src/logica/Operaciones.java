/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import datos.*;
import java.util.List;
import java.util.Date;
/**
 *
 * @author danie
 */
public class Operaciones {
    public boolean Registro(String nickname, String password, String nombre, String apellido, String email, String avatar){
        int id,confirmacion;
        DBJugador db=new DBJugador();
        id=db.getLastId()+1;
        Jugador jugador= new Jugador(id,nickname,password,nombre,apellido,email,avatar);       
        confirmacion=db.insertarJugador(jugador);
        return confirmacion==1;
    }
    public Jugador LogIn(int id, String pw){
        Jugador jugador;
        DBJugador db=new DBJugador();
        jugador=db.getJugadorById(id);
        if((pw.compareTo(jugador.getPassword()))==0)
            return jugador;
        else
            return null;
    }public Jugador LogIn(String nickname, String pw){
        Jugador jugador;
        DBJugador db=new DBJugador();
        jugador=db.getJugadorByNickname(nickname);
        if((pw.compareTo(jugador.getPassword()))==0)
            return jugador;
        else
            return null;
    }
    public Categoria[] Categorias(){
        Categoria[] lista;
        DBCategoria db=new DBCategoria();
        lista=db.getCategoria();
        return lista;
    }
    public Juego[] Juegos(String Nombre){
        Juego[] lista;
        DBJuegoCategoria db=new DBJuegoCategoria();
        lista=db.getJuegoByNombre(Nombre);
        return lista;
    }
    public Puntaje[] b2(String nickname){
        Puntaje[] lista;
        DBPuntaje db=new DBPuntaje();
        lista=db.getJugadorByNickname(nickname);
        return lista;
    }
    public Puntaje[] b3(){
        Puntaje[] lista;
        DBPuntaje db=new DBPuntaje();
        lista=db.getPuntaje();
        return lista;
        
    }
    public boolean Puntuar(String nickname,String nombrej,int puntaje){
        boolean confirmacion=true;
        DBPuntaje db=new DBPuntaje();
        DBJuego db1=new DBJuego();
        DBJugador db2=new DBJugador();
        Date fecha= new Date();        
        int id=db.getLastId();
        id=id+1;
        java.sql.Date fechaSql =  new java.sql.Date(fecha.getTime());
        Puntaje p= new Puntaje(id,db1.getJuegoByNombre(nombrej),db2.getJugadorByNickname(nickname),fechaSql,puntaje);
        int resultado=db.insertarPuntaje(p);
        confirmacion=(1==resultado);
        return confirmacion;
    }
    
}
