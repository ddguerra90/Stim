/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import datos.*;
import java.util.List;

/**
 *
 * @author danie
 */
public class Operaciones {
    public boolean Registro(String nickname, String password, String nombre, String apellido, String email, String avatar){
        int id;
        DBJugador db=new DBJugador();
        id=db.getLastId()+1;
        Jugador jugador= new Jugador(id,nickname,password,nombre,apellido,email,avatar);       
        db.insertarJugador(jugador);
        return true;
    }
    public Jugador LogIn(int id, String pw){
        Jugador jugador;
        DBJugador db=new DBJugador();
        jugador=db.getJugadorById(id);
        if((pw.compareTo(jugador.getPassword()))==0)
            return jugador;
        else
            return null;
    }
    public Juego_Categoria[] b1(){
        Juego_Categoria[] lista;
        DBJuegoCategoria db=new DBJuegoCategoria();
        lista=db.getJuegoCategoria();
        return lista;
    }
    public Puntaje[] b2(Jugador jugador){
        Puntaje[] lista;
        DBPuntaje db=new DBPuntaje();
        lista=db.getJugadorById(jugador.getId());
        return lista;
    }
    public Puntaje[] b3(){
        Puntaje[] lista;
        DBPuntaje db=new DBPuntaje();
        lista=db.getPuntaje();
        return lista;
        
    }
    
}
