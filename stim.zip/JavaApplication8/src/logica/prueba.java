/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import datos.*;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class prueba {
    public static void main(String[] args){
        Operaciones op=new Operaciones();
        //Jugador jugador;
        //DBJugador db=new DBJugador();
        //juego=db.getJugadorById(1);
        Juego juego;
        DBJuego db=new DBJuego();
        juego=db.getJuegoById(1);
        JOptionPane.showMessageDialog(null,op.Puntuar(op.LogIn(1, "1234"), juego, 3000));
        
    }
}
