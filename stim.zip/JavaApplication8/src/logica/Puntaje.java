/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.sql.Date;

/**
 *
 * @author Estudiantes
 */
public class Puntaje {
    
    int id;
    Juego juego;
    Jugador jugador;
    Date fecha;
    int puntaje;

    public Puntaje() {
    }

    public Puntaje(int id, Juego juego, Jugador jugador, Date fecha, int puntaje) {
        this.id = id;
        this.juego = juego;
        this.jugador = jugador;
        this.fecha = fecha;
        this.puntaje = puntaje;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Juego getJuego() {
        return juego;
    }

    public void setJuego(Juego juego) {
        this.juego = juego;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }
    
    
}
