/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.*;

/**
 *
 * @author danie
 */
public class DBJuegoCategoria {
    DBConexion cn;
    
    public DBJuegoCategoria() {
        cn = new DBConexion();
    }
    
    public Juego_Categoria[] getJuegoCategoria(){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego ,juego_categoria ,categoria"
            + " WHERE juego.id=juego_categoria.juego AND categoria.id=juego_categoria.categoria  ");
            ResultSet res = pstm.executeQuery();         

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Juego_Categoria[] data = new Juego_Categoria[registros];
        Juego jue=new Juego();
        Categoria cat=new Categoria();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT j.*"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE j.id=jc.juego AND c.id=jc.categoria  "+
                                                                        "ORDER BY c.id");
            
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i]= new Juego_Categoria();
                jue.setId(res.getInt("id"));
                jue.setNombre(res.getString("nombre"));
                jue.setDescripcion(res.getString("descripcion"));
                jue.setPortada(res.getString("portada"));
                jue.setN_jugadores(res.getInt("n_Jugadores"));
                jue.setPegi(res.getInt("pegi"));
                data[i].setJuego(jue);
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT c.*"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE j.id=jc.juego AND c.id=jc.categoria  "+
                                                                        "ORDER BY c.id");
            
           
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                cat.setId(res.getInt("id"));
                cat.setNombre(res.getString("nombre"));
                cat.setDescripcion(res.getString("descripcion"));
                data[i].setCategoria(cat);
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT jc.*"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE j.id=jc.juego AND c.id=jc.categoria  "+
                                                                        "ORDER BY c.id");
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
       
        return data;
    }
    public Juego_Categoria[] getJuegoById(int idCat){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego ,juego_categoria ,categoria"
            + "WHERE juego.id=juego_categoria.juego AND categoria.id=juego_categoria.categoria AND juego_categoria.categoria=? ");
            pstm.setInt(1, idCat);
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        System.out.println(registros);
        Juego_Categoria[] data = new Juego_Categoria[registros];
        Juego jue=new Juego();
        Categoria cat=new Categoria();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT j.*"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE juego.id=juego_categoria.juego AND categoria.id=juego_categoria.categoria AND juego_categoria.categoria=? "+
                                                                        "ORDER BY c.id");
            
            pstm.setInt(1, idCat);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                jue.setId(res.getInt("id"));
                jue.setNombre(res.getString("nombre"));
                jue.setDescripcion(res.getString("descripcion"));
                jue.setPortada(res.getString("portada"));
                jue.setN_jugadores(res.getInt("n_Jugadores"));
                jue.setPegi(res.getInt("pegi"));
                data[i].setJuego(jue);
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT c.* "
                                                                        + " FROM juego j,juego_categoria jc, categoria c "
                                                                        + " WHERE j.id=jc.juego AND c.id=jc.categoria AND jc.categoria=?"
                                                                        + " ORDER BY c.id");
            
            pstm.setInt(1, idCat);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                cat.setId(res.getInt("id"));
                cat.setNombre(res.getString("nombre"));
                cat.setDescripcion(res.getString("descripcion"));
                data[i].setCategoria(cat);
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT jc.*"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE juego.id=juego_categoria.juego AND categoria.id=juego_categoria.categoria AND juego_categoria.categoria=? "+
                                                                        "ORDER BY c.id");
            
            pstm.setInt(1, idCat);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
       
        return data;
    }
    /** trae una juegoCategoria por su idJue
     * @param idJue
     * @return */
    public Juego_Categoria[] getCategoriaById(int idJue){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego ,juego_categoria ,categoria"
            + "WHERE juego.id=juego_categoria.juego AND categoria.id=juego_categoria.categoria AND juego_categoria.juego=? ");
            pstm.setInt(1, idJue);
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Juego_Categoria[] data = new Juego_Categoria[registros];
        Juego jue=new Juego();
        Categoria cat=new Categoria();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT *"+
                                                                        " FROM juego j,juego_categoria jc, categoria c "+
                                                                        "WHERE juego.id=juego_categoria.juego  AND categoria.id=juego_categoria.categoria AND juego_categoria.juego=? ");
            
            pstm.setInt(1, idJue);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("jc.id"));
                jue.setId(res.getInt("j.id"));
                jue.setNombre(res.getString("j.nombre"));
                jue.setDescripcion(res.getString("j.descripcion"));
                jue.setPortada(res.getString("j.portada"));
                jue.setN_jugadores(res.getInt("j.nJugadores"));
                jue.setPegi(res.getInt("j.pegi"));
                data[i].setJuego(jue);
                cat.setId(res.getInt("c.id"));
                cat.setNombre(res.getString("c.nombre"));
                cat.setDescripcion(res.getString("c.descripcion"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    } 
    
    
}
