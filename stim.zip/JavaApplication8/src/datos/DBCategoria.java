/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.Categoria;

/**
 *
 * @author danie
 */
public class DBCategoria {
    DBConexion cn;
    
    public DBCategoria() {
        cn = new DBConexion();
    }
    public int getLastId(){
        int data=0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT MAX(id) " +
                                                                        " FROM categoria"
                    + " ");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data=(res.getInt("id"));          
                
            }
            res.close();         
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;        
    }
    /** trae una categoria por su id*/
    public Categoria getCategoriaById(int id){
        Categoria data = new Categoria();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " nombre, " +
                                                                                " descripcion "+
                                                                        " FROM categoria " + 
                                                                        " where id = ? ");
            

            pstm.setInt(1, id);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBCategoria dbc = new DBCategoria();
            if(res.next()){
                data = new Categoria();
                data.setId(res.getInt("id"));               
                data.setNombre(res.getString("nombre"));
                data.setDescripcion(res.getString("apellido"));
                
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae todos los registros de la tabla contactos */
     public Categoria[] getCategoria(){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM categoria ");
            
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Categoria[] data = new Categoria[registros];
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " nombre, " +
                                                                                " descripcion "+
                                                                        " FROM categoria ");
            

            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBCategoria dbc = new DBCategoria();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                data[i].setNombre(res.getString("nombre"));
                data[i].setDescripcion(res.getString("apellido"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
     
    public int insertarCategoria(Categoria c){
        int resultado = 0;//no hubo errores de validacion
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("insert into categoria (id, " +
                                                                                " nombre, " +
                                                                                " descripcion ) " +
                                                                    " values(?,?,?)");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.executeUpdate();

            //pstm = cn.getConexion().prepareStatement("select last_insert_id()");
            ResultSet res = pstm.executeQuery();
            res.next();
            resultado = res.getInt(1);
            res.close();
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int actualizarCategoria(Categoria c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("update categoria set id = ?, " +
                                                                               " nombre = ?," +
                                                                               " descrpcion = ?" +
                                                                        " where id = ?");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.setInt(4, c.getId());

            resultado = pstm.executeUpdate();
                    
                
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int borrarCategoria(Categoria c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("delete from categoria " +
                                                                        " where id = ?");
            
            pstm.setInt(1, c.getId());

            resultado = pstm.executeUpdate();
                    
        }catch(SQLException e){
            System.out.println(e);
        }
        
        return resultado;
    }
    
}
