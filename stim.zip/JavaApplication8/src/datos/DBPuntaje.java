/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.*;
import java.util.Date;
import java.lang.Object;

/**
 *
 * @author danie
 */
public class DBPuntaje {
    DBConexion cn;
    
    public DBPuntaje() {
        cn = new DBConexion();
    }
    public Puntaje[] getPuntaje(){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego,puntaje,jugador"
            + " WHERE juego.id=puntaje.juego AND jugador.id=puntaje.jugador  ");
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Puntaje[] data = new Puntaje[registros];
        Juego juego = new Juego();
        Jugador jugador = new Jugador();
       
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT *"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador  "+
                                                                        " ORDER BY s.puntaje");
           
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("s.id"));
                juego.setId(res.getInt("g.id"));
                juego.setNombre(res.getString("g.nombre"));
                juego.setDescripcion(res.getString("g.descripcion"));
                juego.setPortada(res.getString("g.portada"));
                juego.setN_jugadores(res.getInt("g.nJugadores"));
                juego.setPegi(res.getInt("pegi"));
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("pasword"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));
                data[i].setJuego(juego);
                data[i].setJugador(jugador);
                data[i].setPuntaje(res.getInt("s.puntaje"));
                data[i].setFecha(res.getDate("s.fecha"));             
                
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae una puntaje por su idJug
     * @param idJug
     * @return */
    public Puntaje[] getJugadorById(int idJug){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego,puntaje,jugador"
            + " WHERE juego.id=puntaje.juego AND jugador.id=puntaje.jugador AND puntaje.jugador=? ");
            pstm.setInt(1, idJug);
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Puntaje[] data = new Puntaje[registros];
        Juego juego = new Juego();
        Jugador jugador = new Jugador();
       
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT *"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador  AND s.jugador=? ");
            
            pstm.setInt(1, idJug);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("s.id"));
                juego.setId(res.getInt("g.id"));
                juego.setNombre(res.getString("g.nombre"));
                juego.setDescripcion(res.getString("g.descripcion"));
                juego.setPortada(res.getString("g.portada"));
                juego.setN_jugadores(res.getInt("g.nJugadores"));
                juego.setPegi(res.getInt("pegi"));
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("pasword"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));
                data[i].setJuego(juego);
                data[i].setJugador(jugador);
                data[i].setPuntaje(res.getInt("s.puntaje"));
                data[i].setFecha(res.getDate("s.fecha"));             
                
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae una puntaje por su idJue
     * @param idJue
     * @return */
    public Puntaje[] getJuegoById(int idJue){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego,puntaje,jugador"
            + " WHERE juego.id=puntaje.juego AND jugador.id=puntaje.jugador AND puntaje.juego=? ");
            pstm.setInt(1, idJue);
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Puntaje[] data = new Puntaje[registros];
        Juego juego = new Juego();
        Jugador jugador = new Jugador();
       
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT *"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador  AND s.juego=? ");
            
            pstm.setInt(1, idJue);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("s.id"));
                juego.setId(res.getInt("g.id"));
                juego.setNombre(res.getString("g.nombre"));
                juego.setDescripcion(res.getString("g.descripcion"));
                juego.setPortada(res.getString("g.portada"));
                juego.setN_jugadores(res.getInt("g.nJugadores"));
                juego.setPegi(res.getInt("pegi"));
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("pasword"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));
                data[i].setJuego(juego);
                data[i].setJugador(jugador);
                data[i].setPuntaje(res.getInt("s.puntaje"));
                data[i].setFecha(res.getDate("s.fecha"));             
                
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    
}
