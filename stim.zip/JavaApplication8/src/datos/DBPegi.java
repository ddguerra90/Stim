/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.Pegi;

/**
 *
 * @author danie
 */
public class DBPegi {
    DBConexion cn;
    
    public DBPegi() {
        cn = new DBConexion();
    }
    public int getLastId(){
        int data=0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT MAX(id) " +
                                                                        " FROM pegi ");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data=(res.getInt("id"));          
                
            }
            res.close();         
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;        
    }
    /** trae una pegi por su id*/
    public Pegi getPegiById(int id){
        Pegi data = new Pegi();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " juego, " +
                                                                                " descripcion " +
                                                                        " FROM pegi " + 
                                                                        " where id = ? ");
            

            pstm.setInt(1, id);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBPegi dbc = new DBPegi();
            if(res.next()){
                data = new Pegi();
                data.setId(res.getInt("id"));
                data.setNombre(res.getString("nombre"));
                data.setDescripcion(res.getString("descripcion"));                             
                
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae todos los registros de la tabla contactos */
     public Pegi[] getPegi(){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM pegi ");
            
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Pegi[] data = new Pegi[registros];
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " id, " +
                                                                                " nombre, " +
                                                                                " descripcion " +
                                                                        " FROM pegi ");
            

            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBPegi dbc = new DBPegi();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                data[i].setNombre(res.getString("nombre"));
                data[i].setDescripcion(res.getString("descripcion"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
     
    public int insertarPegi(Pegi c){
        int resultado = 0;//no hubo errores de validacion
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("insert into pegi (id, " +
                                                                                " nombre, " +
                                                                                " descripcion) " +
                                                                    " values(?,?,?)");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.executeUpdate();

            //pstm = cn.getConexion().prepareStatement("select last_insert_id()");
            ResultSet res = pstm.executeQuery();
            res.next();
            resultado = res.getInt(1);
            res.close();
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int actualizarPegi(Pegi c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("update pegi set id = ?, " +
                                                                               " nombre = ?," +
                                                                               " descripcion = ?," +
                                                                               " portada = ?," +
                                                                               " apellido = ? " +
                                                                               " nJugadores = ? " +
                                                                        " where id = ?");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.setInt(4, c.getId());

            resultado = pstm.executeUpdate();
                    
                
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int borrarPegi(Pegi c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("delete from pegi " +
                                                                        " where id = ?");
            
            pstm.setInt(1, c.getId());

            resultado = pstm.executeUpdate();
                    
        }catch(SQLException e){
            System.out.println(e);
        }
        
        return resultado;
    }
}
