/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.Juego;

/**
 *
 * @author danie
 */
public class DBJuego {
    DBConexion cn;
    
    public DBJuego() {
        cn = new DBConexion();
    }
    public int getLastId(){
        int data=0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT MAX(id) " +
                                                                        " FROM jugador ");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data=(res.getInt("id"));          
                
            }
            res.close();         
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;        
    }
    /** trae una juego por su id*/
    public Juego getJuegoById(int id){
        Juego data = new Juego();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " id, " +
                                                                                " nombre, " +
                                                                                " descripcion, " +
                                                                                " portada," +
                                                                                " n_Jugadores," +
                                                                                "pegi"+
                                                                        " FROM juego " + 
                                                                        " where id = ? ");
            

            pstm.setInt(1, id);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            if(res.next()){
                data = new Juego();
                data.setId(res.getInt("id"));
                data.setNombre(res.getString("nombre"));
                data.setDescripcion(res.getString("descripcion"));
                data.setPortada(res.getString("portada"));
                data.setN_jugadores(res.getInt("n_Jugadores"));
                data.setPegi(res.getInt("pegi"));              
                
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae todos los registros de la tabla contactos */
     public Juego[] getJuego(){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego ");
            
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Juego[] data = new Juego[registros];
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " id, " +
                                                                                " nombre, " +
                                                                                " descripcion, " +
                                                                                " portada," +
                                                                                " nJugadores," +
                                                                                "pegi"+
                                                                        " FROM juego ");
            

            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                data[i].setNombre(res.getString("nombre"));
                data[i].setDescripcion(res.getString("descripcion"));
                data[i].setPortada(res.getString("portada"));
                data[i].setN_jugadores(res.getInt("nJugadores"));
                data[i].setPegi(res.getInt("pegi"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
     
    public int insertarJuego(Juego c){
        int resultado = 0;//no hubo errores de validacion
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("insert into juego (id, " +
                                                                                " nombre, " +
                                                                                " descripcion, " +
                                                                                " portada," +
                                                                                " nJugadores," +
                                                                                "pegi) " +
                                                                    " values(?,?,?,?,?,?)");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.setString(4, c.getPortada());
            pstm.setInt(5, c.getN_jugadores());
            pstm.setInt(6, c.getPegi());
            pstm.executeUpdate();

            //pstm = cn.getConexion().prepareStatement("select last_insert_id()");
            ResultSet res = pstm.executeQuery();
            res.next();
            resultado = res.getInt(1);
            res.close();
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int actualizarJuego(Juego c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("update juego set id = ?, " +
                                                                               " nombre = ?," +
                                                                               " descripcion = ?," +
                                                                               " portada = ?," +
                                                                               " apellido = ?, " +
                                                                               " nJugadores = ?, " +
                                                                               "pegi=?"+
                                                                        " where id = ?");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNombre());
            pstm.setString(3, c.getDescripcion());
            pstm.setString(4, c.getPortada());
            pstm.setInt(5, c.getN_jugadores());
            pstm.setInt(6, c.getPegi());
            pstm.setInt(7, c.getId());

            resultado = pstm.executeUpdate();
                    
                
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int borrarJuego(Juego c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("delete from juego " +
                                                                        " where id = ?");
            
            pstm.setInt(1, c.getId());

            resultado = pstm.executeUpdate();
                    
        }catch(SQLException e){
            System.out.println(e);
        }
        
        return resultado;
    }
    
}
