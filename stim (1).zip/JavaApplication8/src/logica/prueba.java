/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import datos.*;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class prueba {
    public static void main(String[] args){
        Operaciones op=new Operaciones();
        //Juego[] a=op.Juegos("plataforma");
        //for(int i=0;i<a.length;i++)
          //  System.out.println(a[i].toString());
        System.out.println(op.b2("pepito").length);
    }
}
