/*
 * DBJugador.java
 * 
 * Created on 7/04/2008, 10:26:02 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package datos;

import java.sql.*;
import logica.*;

public class DBJugador {
    DBConexion cn;
    
    public DBJugador() {
        cn = new DBConexion();
    }
    public int getLastId(){
        int data=0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT MAX(id) as id" +
                                                                        " FROM jugador ");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data=(res.getInt("id"));          
                
            }
            res.close();         
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;        
    }
    /** trae una jugador por su id*/    
    public Jugador getJugadorById(int id){
        Jugador data = new Jugador();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " id, " +
                                                                                " nickname, " +
                                                                                " password, " +
                                                                                " nombre," +
                                                                                " apellido," +
                                                                                "email,"+
                                                                                "avatar"+
                                                                        " FROM jugador " + 
                                                                        " where id = ? ");
            

            pstm.setInt(1, id);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data = new Jugador();
                data.setId(res.getInt("id"));
                data.setNickname(res.getString("nickname"));
                data.setPassword(res.getString("password"));
                data.setNombre(res.getString("nombre"));
                data.setApellido(res.getString("apellido"));
                data.setEmail(res.getString("email"));
                data.setAvatar(res.getString("avatar"));               
                
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
    /** trae todos los registros de la tabla contactos */
     public Jugador[] getJugador(){
        int registros = 0;

        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM jugador ");
            
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Jugador[] data = new Jugador[registros];
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " nickname, " +
                                                                                " password, " +
                                                                                " nombre," +
                                                                                " apellido," +
                                                                                "email,"+
                                                                                "avatar"+
                                                                        " FROM jugador ");
            

            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            while(res.next()){
                data[i].setId(res.getInt("id"));
                data[i].setNickname(res.getString("nickname"));
                data[i].setPassword(res.getString("password"));
                data[i].setNombre(res.getString("nombre"));
                data[i].setApellido(res.getString("apellido"));
                data[i].setEmail(res.getString("email"));
                data[i].setAvatar(res.getString("avatar"));
                i++;
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }
     
    public int insertarJugador(Jugador c){
        int resultado = 0;//no hubo errores de validacion
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("insert into jugador (id, " +
                                                                                " nickname, " +
                                                                                " password, " +
                                                                                " nombre," +
                                                                                " apellido," +
                                                                                " email,"+
                                                                                " avatar) " +
                                                                    " values(?,?,?,?,?,?,?)");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNickname());
            pstm.setString(3, c.getPassword());
            pstm.setString(4, c.getNombre());
            pstm.setString(5, c.getApellido());
            pstm.setString(6, c.getEmail());
            pstm.setString(7, c.getAvatar());
            resultado=pstm.executeUpdate();

            
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int actualizarJugador(Jugador c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("update jugador set id = ?, " +
                                                                               " nickname = ?," +
                                                                               " password = ?," +
                                                                               " nombre = ?," +
                                                                               " apellido = ? " +
                                                                               " email = ? " +
                                                                               " avatar = ? " +
                                                                        " where id = ?");
            pstm.setInt(1, c.getId());
            pstm.setString(2, c.getNickname());
            pstm.setString(3, c.getPassword());
            pstm.setString(4, c.getNombre());
            pstm.setString(5, c.getApellido());
            pstm.setString(6, c.getEmail());
            pstm.setString(7, c.getAvatar());
            pstm.setInt(8, c.getId());

            resultado = pstm.executeUpdate();
                    
                
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
    
    public int borrarJugador(Jugador c){
        int resultado = 0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("delete from jugador " +
                                                                        " where id = ?");
            
            pstm.setInt(1, c.getId());

            resultado = pstm.executeUpdate();
                    
        }catch(SQLException e){
            System.out.println(e);
        }
        
        return resultado;
    }

    public Jugador getJugadorByNickname(String nickname) {
        Jugador data = new Jugador();
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT id, " +
                                                                                " id, " +
                                                                                " nickname, " +
                                                                                " password, " +
                                                                                " nombre," +
                                                                                " apellido," +
                                                                                "email,"+
                                                                                "avatar"+
                                                                        " FROM jugador " + 
                                                                        " where nickname = ? ");
            

            pstm.setString(1, nickname);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data = new Jugador();
                data.setId(res.getInt("id"));
                data.setNickname(res.getString("nickname"));
                data.setPassword(res.getString("password"));
                data.setNombre(res.getString("nombre"));
                data.setApellido(res.getString("apellido"));
                data.setEmail(res.getString("email"));
                data.setAvatar(res.getString("avatar"));               
                
            }
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;
    }

}