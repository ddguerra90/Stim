/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import logica.*;
import java.util.Date;
import java.lang.Object;

/**
 *
 * @author danie
 */
public class DBPuntaje {
    DBConexion cn;
    
    public DBPuntaje() {
        cn = new DBConexion();
    }
    public int getLastId(){
        int data=0;
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT MAX(id) as id " +
                                                                        " FROM puntaje ");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJugador dbc = new DBJugador();
            if(res.next()){
                data=(res.getInt("id"));          
                
            }
            res.close();         
        }catch(SQLException e){
            System.out.println(e);
        }
        return data;        
    }
    public Puntaje[] getPuntaje(){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement( "SELECT count(1) as cont FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador  GROUP BY g.id)");
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Puntaje[] data = new Puntaje[registros];
        
        
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT s.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador  GROUP BY g.id)");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            while(res.next()){
                data[i]= new Puntaje();
                data[i].setId(res.getInt("id"));                
                data[i].setPuntaje(res.getInt("puntaje"));
                data[i].setFecha(res.getDate("fecha"));
                i++;
            }
            res.close();                
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT g.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador  GROUP BY g.id)");
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                Juego juego = new Juego();
                juego.setId(res.getInt("id"));
                juego.setNombre(res.getString("nombre"));
                juego.setDescripcion(res.getString("descripcion"));
                juego.setPortada(res.getString("portada"));
                juego.setN_jugadores(res.getInt("n_Jugadores"));
                juego.setPegi(res.getInt("pegi"));
                data[i].setJuego(juego);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT p.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador  GROUP BY g.id)");
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                Jugador jugador = new Jugador();
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("password"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));                
                data[i].setJugador(jugador);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
                
                
        return data;
    }
    /** trae una puntaje por su idJug
     * @param nickname
     * @return */
    public Puntaje[] getJugadorByNickname(String nickname){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement( "SELECT count(1) as cont FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' GROUP BY g.id) ");
            pstm.setString(1, nickname);
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        
        Puntaje[] data = new Puntaje[registros];
        
        
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement( "SELECT s.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' GROUP BY g.id)");
            pstm.setString(1, nickname);
            ResultSet res = pstm.executeQuery();
            int i = 0;
            while(res.next()){
                data[i]= new Puntaje();
                data[i].setId(res.getInt("id"));                
                data[i].setPuntaje(res.getInt("puntaje"));
                data[i].setFecha(res.getDate("fecha"));
                i++;
            }
            res.close();                
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT g.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' GROUP BY g.id)");
            pstm.setString(1, nickname);
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                Juego juego = new Juego();
                juego.setId(res.getInt("id"));
                juego.setNombre(res.getString("nombre"));
                juego.setDescripcion(res.getString("descripcion"));
                juego.setPortada(res.getString("portada"));
                juego.setN_jugadores(res.getInt("n_Jugadores"));
                juego.setPegi(res.getInt("pegi"));
                data[i].setJuego(juego);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT p.* FROM juego g,puntaje s,jugador p \n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' \n" +
                                                                        "AND s.puntaje IN (  SELECT max(s.puntaje)  FROM juego g,puntaje s,jugador p\n" +
                                                                        "WHERE g.id=s.juego AND p.id=s.jugador AND p.nickname='pepito' GROUP BY g.id)");
            pstm.setString(1, nickname);
            
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                Jugador jugador = new Jugador();
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("password"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));                
                data[i].setJugador(jugador);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
                
                
        return data;
    }
    /** trae una puntaje por su idJue
     * @param idJue
     * @return */
    public Puntaje[] getJuegoById(int idJue){
        int registros = 0;
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT count(1) as cont" +
            " FROM juego,puntaje,jugador"
            + " WHERE juego.id=puntaje.juego AND jugador.id=puntaje.jugador  ");
            ResultSet res = pstm.executeQuery();

            res.next();
            registros = res.getInt("cont");
            res.close();	
            
            
        }catch(SQLException e){
            System.out.println(e);
        }
        Puntaje[] data = new Puntaje[registros];
        Juego juego = new Juego();
        Jugador jugador = new Jugador();
        
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT s.*"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador AND puntaje.jugador=? "+
                                                                        " ORDER BY s.puntaje");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            while(res.next()){
                data[i]= new Puntaje();
                data[i].setId(res.getInt("id"));                
                data[i].setPuntaje(res.getInt("puntaje"));
                data[i].setFecha(res.getDate("fecha"));
                i++;
            }
            res.close();                
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT g.*"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador AND puntaje.jugador=?  "+
                                                                        " ORDER BY s.puntaje");
            System.out.println("pase");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                juego.setId(res.getInt("id"));
                juego.setNombre(res.getString("nombre"));
                juego.setDescripcion(res.getString("descripcion"));
                juego.setPortada(res.getString("portada"));
                juego.setN_jugadores(res.getInt("n_Jugadores"));
                juego.setPegi(res.getInt("pegi"));
                data[i].setJuego(juego);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("SELECT p.*"+
                                                                        " FROM juego g,puntaje s,jugador p "+
                                                                        " WHERE g.id=s.juego AND p.id=s.jugador AND puntaje.jugador=?  "+
                                                                        " ORDER BY s.puntaje");
            System.out.println("pase");
            ResultSet res = pstm.executeQuery();
            int i = 0;
            DBJuego dbc = new DBJuego();
            while(res.next()){
                jugador.setId(res.getInt("id"));
                jugador.setNickname(res.getString("nickname"));
                jugador.setPassword(res.getString("password"));
                jugador.setNombre(res.getString("nombre"));
                jugador.setApellido(res.getString("apellido"));
                jugador.setEmail(res.getString("email"));
                jugador.setAvatar(res.getString("avatar"));                
                data[i].setJugador(jugador);
                i++;
            }
            res.close();             
            
        }catch(SQLException e){
            System.out.println(e);
        }
                
                
        return data;
    }

    public int insertarPuntaje(Puntaje p) {
        int resultado = 0;//no hubo errores de validacion
        try{
            PreparedStatement pstm = cn.getConexion().prepareStatement("insert into puntaje (id, " +
                                                                                " juego, " +
                                                                                " jugador, " +
                                                                                " fecha," +
                                                                                " puntaje) " +
                                                                    " values(?,?,?,?,?)");
            pstm.setInt(1, p.getId());
            pstm.setInt(2, p.getJuego().getId());
            pstm.setInt(3, p.getJugador().getId());
            pstm.setDate(4, p.getFecha());
            pstm.setInt(5, p.getPuntaje());
            resultado=pstm.executeUpdate();
            System.out.println(resultado);

            
        }catch(SQLException e){
            System.out.println(e);
        }
        return resultado;
    }
}
